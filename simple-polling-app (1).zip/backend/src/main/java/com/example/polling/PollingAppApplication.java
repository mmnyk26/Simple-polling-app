package com.example.polling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PollingAppApplication {
    public static void main(String[] args) {
        SpringApplication.run(PollingAppApplication.class, args);
    }
}