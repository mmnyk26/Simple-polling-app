package com.example.polling.controller;

import com.example.polling.model.Poll;
import com.example.polling.repository.PollRepository;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/polls")
@CrossOrigin(origins = "*")
public class PollController {
    private final PollRepository pollRepo;

    public PollController(PollRepository pollRepo) {
        this.pollRepo = pollRepo;
    }

    @GetMapping
    public List<Poll> getPolls() {
        return pollRepo.findAll();
    }

    @PostMapping
    public Poll createPoll(@RequestBody Poll poll) {
        return pollRepo.save(poll);
    }

    @PostMapping("/{id}/vote")
    public Poll vote(@PathVariable Long id, @RequestBody Map<String, String> voteReq) {
        Poll poll = pollRepo.findById(id).orElseThrow();
        String opt = voteReq.get("option");
        poll.getVotes().put(opt, poll.getVotes().getOrDefault(opt, 0) + 1);
        return pollRepo.save(poll);
    }
}