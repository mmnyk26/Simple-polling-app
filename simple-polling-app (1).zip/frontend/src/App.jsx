import React, { useState, useEffect } from 'react';

function App() {
  const [polls, setPolls] = useState([]);
  const [question, setQuestion] = useState('');
  const [options, setOptions] = useState(['', '']);

  useEffect(() => {
    fetch('http://localhost:8080/api/polls')
      .then(res => res.json())
      .then(data => setPolls(data));
  }, []);

  const handleCreatePoll = () => {
    fetch('http://localhost:8080/api/polls', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question, options }),
    }).then(() => window.location.reload());
  };

  const handleVote = (pollId, option) => {
    fetch(`http://localhost:8080/api/polls/${pollId}/vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ option }),
    }).then(() => window.location.reload());
  };

  return (
    <div className="p-4 max-w-xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Create Poll</h1>
      <input className="border p-2 w-full mb-2" value={question} onChange={e => setQuestion(e.target.value)} placeholder="Poll question" />
      {options.map((opt, i) => (
        <input key={i} className="border p-2 w-full mb-2" value={opt} onChange={e => {
          const newOptions = [...options];
          newOptions[i] = e.target.value;
          setOptions(newOptions);
        }} placeholder={`Option ${i + 1}`} />
      ))}
      <button className="bg-blue-500 text-white px-4 py-2" onClick={handleCreatePoll}>Create</button>

      <h2 className="text-xl font-semibold mt-8">Polls</h2>
      {polls.map(poll => (
        <div key={poll.id} className="border p-4 mt-4">
          <h3 className="font-semibold">{poll.question}</h3>
          {poll.options.map(opt => (
            <div key={opt}>
              <button className="text-blue-500 underline" onClick={() => handleVote(poll.id, opt)}>{opt}</button>
              <span className="ml-2">({poll.votes[opt] || 0} votes)</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

export default App;
