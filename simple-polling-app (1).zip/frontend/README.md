# Frontend for Simple Polling App
React.js with TailwindCSS